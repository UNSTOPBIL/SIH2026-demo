"""
rule_engine.py — Refactored statutory compliance rule evaluation engine for Legal Metrology Rule 6.
Supports text normalization, intermediate evidence representation, categorical compliance states,
and product context applicability.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple, Union


def normalize_ocr_text(text: str) -> str:
    """
    Normalize raw OCR text to tolerate OCR artifacts, missing spaces,
    and character corruptions.
    """
    if not text:
        return ""
    
    t = text.strip()
    # Normalize common OCR prefixes and punctuation corruptions
    t_clean = re.sub(r"(?i)mfd\.?\s*byc\)", "Mfd. by ", t)
    t_clean = re.sub(r"(?i)mfd\.?\s*by", "Mfd. by ", t_clean)
    t_clean = re.sub(r"(?i)mfg\.?\s*by", "Mfg. by ", t_clean)
    t_clean = re.sub(r"(?i)mktd\.?\s*by", "Mktd. by ", t_clean)
    t_clean = re.sub(r"(?i)pkd\.?\s*by", "Pkd. by ", t_clean)
    t_clean = re.sub(r"(?i)mfr\.?\s*by", "Mfr. by ", t_clean)
    t_clean = re.sub(r"(?i)l['’`]?oreal", "L'Oreal", t_clean)
    return t_clean


def parse_ocr_inputs(
    ocr_input: Union[List[str], List[Dict[str, Any]]]
) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    Standardize OCR input into parallel lists of text lines and detailed evidence dicts.
    """
    lines: List[str] = []
    details: List[Dict[str, Any]] = []

    for idx, item in enumerate(ocr_input):
        if isinstance(item, str):
            lines.append(item)
            details.append({
                "line_id": idx,
                "text": item,
                "confidence": 1.0,
                "box": []
            })
        elif isinstance(item, dict):
            text = item.get("text", "")
            lines.append(text)
            details.append({
                "line_id": item.get("line_id", idx),
                "text": text,
                "confidence": item.get("confidence", 1.0),
                "box": item.get("box", [])
            })
    return lines, details


def evaluate_compliance(
    ocr_input: Union[List[str], List[Dict[str, Any]]],
    config_path: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Evaluate extracted OCR text lines against statutory Legal Metrology Rule 6 requirements.

    Args:
        ocr_input: List of raw strings OR list of OCR detail dicts (with line_id, text, confidence, box).
        config_path: Optional path to guardrails config.
        context: Optional dictionary specifying product_category and imported status.

    Returns:
        Structured evaluation dictionary containing verdict_state, summary counts,
        findings, and evidence details.
    """
    if context is None:
        context = {
            "product_category": "Cosmetic / Personal Care",
            "imported": False
        }

    category = context.get("product_category", "Cosmetic / Personal Care")
    is_imported = context.get("imported", False)

    ocr_lines, ocr_details = parse_ocr_inputs(ocr_input)
    normalized_lines = [normalize_ocr_text(l) for l in ocr_lines]
    full_text = "\n".join(normalized_lines)
    flat_text = " ".join(normalized_lines)

    findings: List[Dict[str, Any]] = []

    # Helper function to find best OCR line match for evidence tracing
    def find_ocr_evidence(pattern: str) -> Optional[Dict[str, Any]]:
        for det, norm in zip(ocr_details, normalized_lines):
            if re.search(pattern, norm, re.IGNORECASE) or re.search(pattern, det["text"], re.IGNORECASE):
                return det
        return None

    # 1. MRP (Rule 6(1)(f)) vs Unit Sale Price
    mrp_finding = _evaluate_mrp(ocr_details, normalized_lines, full_text, flat_text)
    findings.append(mrp_finding)

    # 2. Net Quantity (Rule 6(1)(b))
    net_qty_finding = _evaluate_net_quantity(ocr_details, normalized_lines, full_text, flat_text)
    findings.append(net_qty_finding)

    # 3. Manufacturer / Packer / Importer Details (Rule 6(1)(c))
    mfr_finding = _evaluate_manufacturer(ocr_details, normalized_lines, full_text, flat_text, is_imported)
    findings.append(mfr_finding)

    # 4. Manufacturing / Packing Date (Rule 6(1)(e))
    mfg_date_finding = _evaluate_mfg_date(ocr_details, normalized_lines, full_text, flat_text)
    findings.append(mfg_date_finding)

    # 5. Best Before / Expiry Date (Rule 6(1)(e))
    expiry_finding = _evaluate_expiry_date(ocr_details, normalized_lines, full_text, flat_text)
    findings.append(expiry_finding)

    # 6. Consumer Care / Grievance Cell (Rule 6(1)(k))
    care_finding = _evaluate_consumer_care(ocr_details, normalized_lines, full_text, flat_text)
    findings.append(care_finding)

    # 7. Sector-Specific (FSSAI / BIS License)
    fssai_finding = _evaluate_fssai(ocr_details, normalized_lines, full_text, flat_text, category)
    findings.append(fssai_finding)

    # Compute Summary Counts
    passed_cnt = sum(1 for f in findings if f["status"] == "PASS")
    review_cnt = sum(1 for f in findings if f["status"] == "REVIEW_REQUIRED")
    violation_cnt = sum(1 for f in findings if f["status"] == "FAIL")
    not_app_cnt = sum(1 for f in findings if f["status"] == "NOT_APPLICABLE")
    not_det_cnt = sum(1 for f in findings if f["status"] == "NOT_DETECTED")
    detected_cnt = len(findings) - not_det_cnt - not_app_cnt

    # Overall Verdict Determination
    if violation_cnt > 0:
        verdict_state = "POTENTIAL_VIOLATION"
        is_compliant = False
    elif review_cnt > 0:
        verdict_state = "REVIEW_REQUIRED"
        is_compliant = False
    else:
        verdict_state = "COMPLIANT"
        is_compliant = True

    # Build backward-compatible card structure for UI
    cards = []
    for f in findings:
        legacy_status = "PASS" if f["status"] == "PASS" else ("FAIL" if f["status"] == "FAIL" else ("WARN" if f["status"] in ["REVIEW_REQUIRED", "NOT_APPLICABLE", "WARNING"] else "FAIL"))
        cards.append({
            "id": f["field"],
            "label": f["label"],
            "rule_ref": f["rule_ref"],
            "description": f["description"],
            "required": f["status"] not in ["NOT_APPLICABLE"],
            "passed": f["status"] == "PASS",
            "status": legacy_status,
            "actual_status": f["status"],
            "snippet": f["value"] if f["value"] else "Not detected on packaging label",
            "matched_pattern_idx": 0 if f["evidence"] else -1,
            "evidence": f["evidence"],
            "confidence": f["confidence"]
        })

    return {
        "is_compliant": is_compliant,
        "verdict_state": verdict_state,
        "score_percentage": round((passed_cnt / max(1, (len(findings) - not_app_cnt)) * 100), 1),
        "summary": {
            "declarations_detected": detected_cnt,
            "passed_count": passed_cnt,
            "review_count": review_cnt,
            "violation_count": violation_cnt,
            "not_applicable_count": not_app_cnt,
            "not_detected_count": not_det_cnt,
            "total_rules": len(findings),
            "required_total": len(findings) - not_app_cnt,
            "required_passed": passed_cnt,
            "required_failed": violation_cnt,
        },
        "findings": findings,
        "cards": cards,
        "ocr_line_count": len(ocr_lines),
    }


def _evaluate_mrp(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str
) -> Dict[str, Any]:
    field = "mrp"
    label = "MRP (incl. of all taxes)"
    rule_ref = "Rule 6(1)(f)"
    desc = "Maximum Retail Price inclusive of all taxes must be clearly stated."

    # Look for Unit Sale Price first to avoid false MRP matches (e.g. Rs.2.30/100g)
    usp_match = re.search(r"(?i)(?:Rs\.?|INR|₹)\s*\d+(?:\.\d{1,2})?\s*/\s*(?:100g|100ml|g|ml|kg|l|unit)", flat_text)
    
    # Patterns for MRP
    mrp_patterns = [
        r"(?i)(M\.?R\.?P\.?|Maximum\s+Retail\s+Price)[^\n\r]{0,35}?(₹|Rs\.?|INR)?\s*([0-9]+(?:\.[0-9]{1,2})?)",
        r"(?i)\b(M\.?R\.?P\.?)\s*[:.-]?\s*(?:Rs\.?|INR|₹)?\s*\d+(?:\.\d{1,2})?\b",
        r"(?i)\b(Rs\.?|INR|₹)\s*\d+(\.\d{1,2})?\b"
    ]

    matched_det = None
    extracted_val = ""

    for det, norm in zip(ocr_details, normalized_lines):
        # Skip unit sale price lines for primary MRP unless explicit MRP keyword exists
        if "/" in norm and "mrp" not in norm.lower():
            continue
        for pat in mrp_patterns:
            m = re.search(pat, norm)
            if not m:
                m = re.search(pat, det["text"])
            if m:
                # Exclude nutrition words ending in 'rs' e.g. Total Sugars 19
                matched_str = m.group(0)
                if re.search(r"(?i)sugars|calories|carbs", norm):
                    continue
                matched_det = det
                extracted_val = matched_str.strip()
                break
        if matched_det:
            break

    if matched_det:
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": "PASS",
            "value": extracted_val,
            "raw_text": matched_det["text"],
            "confidence": matched_det["confidence"],
            "evidence": {
                "line_ids": [matched_det["line_id"]],
                "bbox": matched_det["box"],
                "snippet": matched_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "FAIL",
        "value": "MRP declaration missing",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }


def _evaluate_net_quantity(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str
) -> Dict[str, Any]:
    field = "net_quantity"
    label = "Net Quantity (Standard Units)"
    rule_ref = "Rule 6(1)(b)"
    desc = "Net quantity in standard units of weight, measure or number."

    patterns = [
        r"(?i)(net\s*(?:qty|quantity|wt|weight|vol|volume|content))[\s.:-]*([0-9]+(?:\.[0-9]+)?)\s*(kg|g|gm|gms|grams|kilograms|ml|millilitre|l|ltr|litre|litres|nos|n|units|pieces|pcs)\b",
        r"(?i)\b([0-9]+(?:\.[0-9]+)?)\s*(kg|g|gm|gms|ml|ltr|litre|litres)\b"
    ]

    matched_det = None
    extracted_val = ""

    for det, norm in zip(ocr_details, normalized_lines):
        for pat in patterns:
            m = re.search(pat, norm)
            if not m:
                m = re.search(pat, det["text"])
            if m:
                matched_det = det
                extracted_val = m.group(0).strip()
                break
        if matched_det:
            break

    if matched_det:
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": "PASS",
            "value": extracted_val,
            "raw_text": matched_det["text"],
            "confidence": matched_det["confidence"],
            "evidence": {
                "line_ids": [matched_det["line_id"]],
                "bbox": matched_det["box"],
                "snippet": matched_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "FAIL",
        "value": "Net Quantity missing",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }


def _evaluate_manufacturer(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str,
    is_imported: bool
) -> Dict[str, Any]:
    field = "manufacturer"
    label = "Manufacturer / Packer Details"
    rule_ref = "Rule 6(1)(c)"
    desc = "Name and complete address of the manufacturer, packer, or importer."

    # Patterns matching manufacturer indicators (including Garnier OCR artifacts)
    mfr_patterns = [
        r"(?i)(mfd\.?\s*by|mfg\.?\s*by|manufactured\s+by|packed\s+by|marketed\s+by|distributed\s+by|imported\s+by|pkd\.?\s*by|mfr\.?\s*by|mktd\.?\s*by|mfd\.?byc\))[\s:.-]*([A-Za-z0-9\s,.'-]{4,100})",
        r"(?i)\b(l['’`]?oreal|fastsnacks|naturepure|seeds of change|global brands|apex imports|l'oreal india)\b",
        r"(?i)\b(manufactured|packed|marketed|distributed|imported)\s*(by|&|and)?\b"
    ]

    matched_det = None
    extracted_val = ""

    for det, norm in zip(ocr_details, normalized_lines):
        for pat in mfr_patterns:
            m = re.search(pat, norm)
            if not m:
                m = re.search(pat, det["text"])
            if m:
                matched_det = det
                extracted_val = det["text"].strip()
                break
        if matched_det:
            break

    if matched_det:
        # Check if address completeness is partial (e.g. Garnier "Chakan, Pune - 410501")
        has_pin_or_state = re.search(r"\b\d{6}\b|[A-Za-z]{2,}\b", extracted_val)
        status = "PASS" if len(extracted_val) > 12 else "REVIEW_REQUIRED"

        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": status,
            "value": extracted_val,
            "raw_text": matched_det["text"],
            "confidence": matched_det["confidence"],
            "evidence": {
                "line_ids": [matched_det["line_id"]],
                "bbox": matched_det["box"],
                "snippet": matched_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "FAIL",
        "value": "Manufacturer/Packer details not detected",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }


def _evaluate_mfg_date(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str
) -> Dict[str, Any]:
    field = "mfg_date"
    label = "Mfg / Packing Date"
    rule_ref = "Rule 6(1)(e)"
    desc = "Month and year of manufacture or packing."

    date_patterns = [
        r"(?i)(mfg\.?\s*date|mfd\.?|pkd\.?|packed\s+on|date\s+of\s+mfg|manufactured\s+on)[\s:.-]*([0-9]{1,2}[/\-.\s][0-9]{2,4}|[A-Za-z]{3,9}[\s-]*[0-9]{2,4})",
        r"(?i)\b(0[1-9]|1[0-2])[/\-.](20\d{2}|\d{2})\b"
    ]

    ambiguous_code_pattern = r"\b\d{2}/\d{4}/\d{2}\b|\b\d{2}/\d{2}/\d{4}\b"

    matched_det = None
    extracted_val = ""
    is_ambiguous = False

    for det, norm in zip(ocr_details, normalized_lines):
        if re.search(ambiguous_code_pattern, norm):
            matched_det = det
            extracted_val = det["text"].strip()
            is_ambiguous = True
            break
        for pat in date_patterns:
            m = re.search(pat, norm)
            if not m:
                m = re.search(pat, det["text"])
            if m:
                matched_det = det
                extracted_val = m.group(0).strip()
                break
        if matched_det:
            break

    if matched_det:
        status = "REVIEW_REQUIRED" if is_ambiguous else "PASS"
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": status,
            "value": extracted_val,
            "raw_text": matched_det["text"],
            "confidence": matched_det["confidence"],
            "evidence": {
                "line_ids": [matched_det["line_id"]],
                "bbox": matched_det["box"],
                "snippet": matched_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "REVIEW_REQUIRED",
        "value": "Mfg date uncertain or not detected",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }


def _evaluate_expiry_date(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str
) -> Dict[str, Any]:
    field = "expiry_date"
    label = "Best Before / Expiry Date"
    rule_ref = "Rule 6(1)(e)"
    desc = "Best before date or expiry date declaration."

    exp_patterns = [
        r"(?i)(best\s+before|use\s+by|exp\.?\s*date|expiry\s*date|exp\.?)[^\n\r]{0,40}?",
        r"(?i)(best\s+before)[\s:.-]*([0-9]+\s*(?:months|days|years|year))"
    ]

    matched_det = None
    extracted_val = ""

    for det, norm in zip(ocr_details, normalized_lines):
        for pat in exp_patterns:
            m = re.search(pat, norm)
            if not m:
                m = re.search(pat, det["text"])
            if m:
                matched_det = det
                extracted_val = det["text"].strip()
                break
        if matched_det:
            break

    if matched_det:
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": "PASS",
            "value": extracted_val,
            "raw_text": matched_det["text"],
            "confidence": matched_det["confidence"],
            "evidence": {
                "line_ids": [matched_det["line_id"]],
                "bbox": matched_det["box"],
                "snippet": matched_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "REVIEW_REQUIRED",
        "value": "Expiry / Best Before date not established",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }


def _evaluate_consumer_care(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str
) -> Dict[str, Any]:
    field = "consumer_care"
    label = "Consumer Care / Grievance Cell"
    rule_ref = "Rule 6(1)(k)"
    desc = "Name, address, phone number or email for consumer complaints."

    care_phrase_pattern = r"(?i)(consumer\s*(?:care|cell|helpline|service|advisor)|customer\s*(?:care|support|service)|toll\s*free|help\s*line|grievance|questions/complaints|call\s+or\s+write)"
    contact_details_pattern = r"(?i)(1800[\s-]?[0-9]{3}[\s-]?[0-9]{3,4}|[0-9]{10}|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})"

    matched_phrase_det = None
    has_contact_info = False
    extracted_val = ""

    for det, norm in zip(ocr_details, normalized_lines):
        if re.search(care_phrase_pattern, norm) or re.search(care_phrase_pattern, det["text"]):
            matched_phrase_det = det
            extracted_val = det["text"].strip()
            if re.search(contact_details_pattern, norm) or re.search(contact_details_pattern, det["text"]):
                has_contact_info = True
            break

    # Search entire text for contact info if phrase was found
    if matched_phrase_det and not has_contact_info:
        if re.search(contact_details_pattern, flat_text):
            has_contact_info = True

    if matched_phrase_det:
        status = "PASS" if has_contact_info else "REVIEW_REQUIRED"
        val = extracted_val if has_contact_info else f"{extracted_val} (Contact details incomplete)"
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": status,
            "value": val,
            "raw_text": matched_phrase_det["text"],
            "confidence": matched_phrase_det["confidence"],
            "evidence": {
                "line_ids": [matched_phrase_det["line_id"]],
                "bbox": matched_phrase_det["box"],
                "snippet": matched_phrase_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "FAIL",
        "value": "Consumer Care contact missing",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }


def _evaluate_fssai(
    ocr_details: List[Dict[str, Any]],
    normalized_lines: List[str],
    full_text: str,
    flat_text: str,
    product_category: str
) -> Dict[str, Any]:
    field = "fssai_license"
    label = "FSSAI / BIS License No."
    rule_ref = "Rule 6 (Sector Specific)"
    desc = "Food safety or BIS standardization license number."

    if "Food" not in product_category and "Beverage" not in product_category:
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": "NOT_APPLICABLE",
            "value": "Not Applicable for non-food sector",
            "raw_text": "",
            "confidence": 1.0,
            "evidence": None
        }

    fssai_pattern = r"(?i)(fssai|lic\.?\s*no\.?|license\s+no\.?)[\s.:-]*([0-9]{14}|[0-9A-Z-]{8,20})"

    matched_det = None
    extracted_val = ""

    for det, norm in zip(ocr_details, normalized_lines):
        m = re.search(fssai_pattern, norm)
        if m:
            matched_det = det
            extracted_val = m.group(0).strip()
            break

    if matched_det:
        return {
            "field": field,
            "label": label,
            "rule_ref": rule_ref,
            "description": desc,
            "status": "PASS",
            "value": extracted_val,
            "raw_text": matched_det["text"],
            "confidence": matched_det["confidence"],
            "evidence": {
                "line_ids": [matched_det["line_id"]],
                "bbox": matched_det["box"],
                "snippet": matched_det["text"]
            }
        }

    return {
        "field": field,
        "label": label,
        "rule_ref": rule_ref,
        "description": desc,
        "status": "REVIEW_REQUIRED",
        "value": "FSSAI License not detected",
        "raw_text": "",
        "confidence": 0.0,
        "evidence": None
    }
